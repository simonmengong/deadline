import React, { Component } from 'react';
import {Card, CardDeck, Button, Navbar, Nav, Container, Alert} from 'react-bootstrap';
import axios from 'axios';
import 'react-bootstrap-typeahead/css/Typeahead.css';
import moment from 'moment';
import MediaQuery from 'react-responsive';
import { Link } from 'react-router-dom';
import bg1 from '../img/bg1.jpg';
import bg2 from '../img/bg2.jpg';
import bg3 from '../img/bg3.jpg';
import bg4 from '../img/bg4.jpg';

class Accueil extends Component {
    constructor(props) {
        super(props);
        this.state = {
            alert: this.props.match.params.success !== undefined? true : false,
            width: 0
        };
    }

    componentDidMount(props){
        /*let storage = window.localStorage;
        this.setState({
            token: storage.getItem('token')
        });
        window.scrollTo(0, 0)*/
        let width = window.innerWidth
        || document.documentElement.clientWidth
        || document.body.clientWidth;
        this.setState({width: width})

    }

    componentDidUpdate(props){
       /* let that = this;
        if(!this.state.updated){
            that.getContract();
            if(that.state.contract){
                that.setState({updated: true});
            }
        }*/
      }

    render() {
        return (
            <>
                {this.state.alert?
                    <Card className="rounded-0 border-0 px-0">
                        <Card.Body className="px-0">
                            <Alert variant="success" className="mx-0" onClose={() => this.setState({alert: false})} dismissible>
                                <Alert.Heading>Félicitations!</Alert.Heading>
                                <p>
                                Le contrat a été enregistré avec succès.
                                </p>
                            </Alert>
                        </Card.Body>
                    </Card>
                    :
                    <></>
                }
                <MediaQuery query='(min-width: 768px)'>
                    <Card className="text-white rounded-0 border-0" style={{height: "40vh"}}>
                        <Card.Img src={bg1} alt="Card image" style={{objectFit: "cover", height: "40vh"}}/>
                        <Card.ImgOverlay style={{backgroundColor: "rgba(0,0,0,.6)"}} className="border-0 rounded-0">
                            
                            <Card.Title className="mb-4" style={{fontSize: "2em"}}>Bienvenue sur Dateliner !</Card.Title>
                            <Card.Text style={{fontSize: "1.6em"}}>
                            Votre plateforme de gestion des échéeances et des relances de vos clients.
                            </Card.Text>
                        </Card.ImgOverlay>
                    </Card>
                </MediaQuery>
                <MediaQuery query='(max-width: 768px)'>
                    <Card className="text-white rounded-0 border-0" style={{height: "48vh"}}>
                        <Card.Img src={bg1} alt="Card image" style={{objectFit: "cover", height: "48vh"}}/>
                        <Card.ImgOverlay style={{backgroundColor: "rgba(0,0,0,.6)"}} className="border-0 rounded-0">
                            
                            <Card.Title className="mb-4" style={{fontSize: "1.6em"}}>Bienvenue sur Dateliner !</Card.Title>
                            <Card.Text style={{fontSize: "1.2em"}}>
                            Votre plateforme de gestion des échéeances et des relances de vos clients.
                            </Card.Text>
                        </Card.ImgOverlay>
                    </Card>
                </MediaQuery>
                

                <Card bg="transparent" body className="border-0">
                    <Card.Title className="border-bottom pb-2">Les Fonctionnalités</Card.Title>
                </Card>

                <CardDeck className="px-3 mb-5 text-white">
                    <Card className="border-0 rounded-0 mb-3" style={{minWidth: "14rem", minHeight: "16rem"}}>
                        <Card.Img src={bg2} style={{objectFit: "cover", minHeight: "16rem"}}/>
                        <Card.ImgOverlay style={{backgroundColor: "rgba(0,0,0,.6)"}} className="border-0 rounded-0">
                            <Card.Title>Contrats de créance</Card.Title>
                            <Card.Text>
                                Complètez le formulaire du contrat de créance dans lequel vous entrerez les informations du client. Les échéances, les moyens de relance.
                            </Card.Text>
                            <Link to="/contract">
                                <Button variant="light" size="sm" className="rounded-0">Commencer</Button>
                            </Link>              
                        </Card.ImgOverlay>
                    </Card>
                    <Card className="border-0 rounded-0 mb-3" style={{minWidth: "14rem",  minHeight: "16rem"}}>
                        <Card.Img src={bg3} style={{objectFit: "cover", minHeight: "16rem"}}/>
                        <Card.ImgOverlay style={{backgroundColor: "rgba(0,0,0,.6)"}} className="border-0 rounded-0">
                            <Card.Title>Gestion des échéances</Card.Title>
                            <Card.Text>
                                Controlez et modifiez les échéances de payement de vos clients.
                            </Card.Text>
                            <Link to="/customers">
                                <Button variant="light" size="sm" className="rounded-0">Commencer</Button>
                            </Link>
                        </Card.ImgOverlay>
                    </Card>
                    <Card className="border-0 rounded-0 mb-3" style={{minWidth: "14rem",  minHeight: "16rem"}}>
                        <Card.Img src={bg4} style={{objectFit: "cover", minHeight: "16rem"}}/>
                        <Card.ImgOverlay style={{backgroundColor: "rgba(0,0,0,.6)"}} className="border-0 rounded-0">
                            <Card.Title>Gestion des relances</Card.Title>
                            <Card.Text>
                                Grâce aux moyens de plusieurs APIs, vous pourrez automatiquement ou manuellement relancer vos clients.
                            </Card.Text>
                            <Link to="/customers">
                                <Button variant="light" size="sm" className="rounded-0">Commencer</Button>
                            </Link>
                        </Card.ImgOverlay>
                    </Card>
                    {this.state.width> 765?
                        <MediaQuery query='(max-width: 992px)'>
                            <Card className="border-0 rounded-0 mb-3" style={{minWidth: "14rem",  minHeight: "16rem", visibility: "hidden"}}>
                                <Card.Img src={bg4} style={{objectFit: "cover", minHeight: "16rem"}}/>
                                <Card.ImgOverlay style={{backgroundColor: "rgba(0,0,0,.6)"}} className="border-0 rounded-0">
                                    <Card.Title>Gestion des relances</Card.Title>
                                    <Card.Text>
                                        Grâce aux moyens de plusieurs APIs, vous pourrez automatiquement ou manuellement relancer vos clients.
                                    </Card.Text>
                                    <Link to="/customers">
                                        <Button variant="light" size="sm" className="rounded-0">Commencer</Button>
                                    </Link>
                                </Card.ImgOverlay>
                            </Card>
                        </MediaQuery>:
                        <></>
                    }
                    
                </CardDeck>
            </>
        )
    }
}

export default Accueil;