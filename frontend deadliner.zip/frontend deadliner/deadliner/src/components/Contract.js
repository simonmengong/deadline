import React, { Component } from 'react';
import {Card, Button, Navbar, Nav, Container, Row, Col, Form, Spinner, Modal} from 'react-bootstrap';
import axios from 'axios';
import { Typeahead } from 'react-bootstrap-typeahead';
import 'react-bootstrap-typeahead/css/Typeahead.css';
import { DatePicker } from "react-tempusdominus-bootstrap";
import moment from 'moment';
import MediaQuery from 'react-responsive';
import writtenNumber from 'written-number';
import { BrowserRouter as Router, Route, Switch, Redirect, Link } from 'react-router-dom';


class Contract extends Component {
    constructor(props) {
        super(props);
        this.state = {
            token: "",
            updated: false,
            input_echeances: [],
            input_garants: [],
            ids_input_garants: [],
            deadlineNumber: 0,
            total_created_garants: 0,
            currencies: [],
            reminder_means: [],
            customers: [],
            amount_letters: 'zero',
            penalty_amount: 0,
            startDate: moment(),
            submitting: false,
            timeliner: props.match.params.id? props.match.params.id.replace(':',''): "",
            modal: false,
            
            //timeline
            motif: "",
            amount_indebted: 0,
            due_date: "",
            date_liner_number: 0,
            penalty_rate: 0,
            partner_id: "",
            currency: "",
            client_agreement: false,

            //deadline
            deadlines: [],

            //reminder
            reminders: [],
            reminders_list: [],

            //guarantee
            guarantees: [],

            //check
            printed: false,
            submitted: false,
            valid_client: false,
            valid_motif: false,
            valid_montant: false,
            valid_deadline_number: false,
            valid_due_date: false,
            valid_penalty: false,
            valid_deadlines_amount: false,
            valid_deadlines_date: false,
            valid_guarantees_amount: false,
            deadlines_filled: false,
            guarantees_filled: false,
            ok: false,
            contractReady: props.match.params.id? true: false,

        };
        this.reset_echeance_inputs = this.reset_echeance_inputs.bind(this);
        this.add_garant_input = this.add_garant_input.bind(this);
        this.delete_garant_input = this.delete_garant_input.bind(this);
        this.handleFileSelect = this.handleFileSelect.bind(this);
        this.check_deadlines = this.check_deadlines.bind(this);
        this.check_garants = this.check_garants.bind(this);
        this.submit = this.submit.bind(this);
        this.submit_timeliner = this.submit_timeliner.bind(this);
        this.submit_dateliner = this.submit_dateliner.bind(this);
        this.submit_reminders = this.submit_reminders.bind(this);
        this.handle_message = this.handle_message.bind(this);
        this.can_submit = this.can_submit.bind(this);
    }

    componentDidMount(props){
        let storage = window.localStorage;
        this.setState({
            token: storage.getItem('token')
        });
        window.scrollTo(0, 0);
        window.addEventListener('message', this.handle_message);
    }

    handle_message(event){
        let frame = document.getElementById('frame');
        frame.style.height = (event.data - 0) + 12 + 'px';
    }

    componentWillUnmount() {
        window.removeEventListener('message', this.handle_message);
      }

    componentDidUpdate(props){
        let that = this;
        if(!that.state.updated){
            axios.get(`https://api-ksm-dateliner.herokuapp.com/api/currency/`, {
                headers: {
                    'authorization': `Token ${this.state.token}`}
            })
            .then(function (response) {
                that.setState({
                    currencies: response.data,
                    currency: response.data[0].id
                });
            })
            .catch(function (error){
                console.log(error);
            });
            axios.get(`https://api-ksm-dateliner.herokuapp.com/api/reminder_mean/`, {
                headers: {
                    'authorization': `Token ${this.state.token}`}
            })
            .then(function (response) {
                that.setState({reminder_means: response.data});
                let reminders_list = [];
                for(var i=0; i<response.data.length; i++){
                    reminders_list.push(response.data[i].id);
                }
                that.setState({reminders_list: reminders_list});
            })
            .catch(function (error){
                console.log(error);
            });
            axios.get(`https://anselme.pythonanywhere.com/partner-api/partners/`, {
                headers: {
                    'authorization': `Basic ${btoa("simon" + ":" + "simonsuperuser")}`}
            })
            .then(function (response) {
                let customers = response.data['results'].map((customer, id) =>{
                    return({label: customer.name, id: customer.id})
                })
                that.setState({customers: customers});
            })
            .catch(function (error){
                console.log(error);
            });
            that.setState({updated: true});
        }

      }

    reset_echeance_inputs(n){
        let that = this;
        let inputs = [];
        let deadlines = []
        for (var i=0; i < n; i++){
            let k = i;
            inputs.push(
                <Form.Group as={Row} controlId="formPlaintextPassword" key={i}>
                    <Form.Label column sm="4">
                    Échéance {i+1}*:
                    </Form.Label>
                    <Col sm="4">
                    <Form.Control type="number" placeholder="Montant" 
                    onChange={(e)=>{
                        let deadlines = this.state.deadlines;
                        deadlines[k].payable_amount = e.target.value;
                        this.setState({deadlines: deadlines.slice(0)});
                        this.check_deadlines();
                    }}
                    />
                    </Col>
                    <Col sm="4">
                    <DatePicker
                    onChange={(e)=>{
                        let deadlines = this.state.deadlines;
                        deadlines[k].deadline_date = e.date;
                        this.setState({deadlines: deadlines.slice(0)});
                        this.check_deadlines();
                    }}
                    minDate={that.state.startDate}
                    />
                    </Col>
                </Form.Group>
            );
            deadlines.push({"payable_amount": 0, "deadline_date": that.state.due_date})
        }
        that.setState({input_echeances: inputs.slice(0), deadlineNumber: n, deadlines: deadlines.slice(0)});
    }

    add_garant_input(e){
        let that = this;
        let inputs = that.state.input_garants;
        let ids = that.state.ids_input_garants;
        let n = that.state.total_created_garants;
        ids.push(n);
        inputs.push(
            <Card body bg="transparent" className="px-0 mx-0 border-0 rounded-0" key={n}>
                <Card.Text className="border-bottom pb-2 d-flex justify-content-between">
                    <span id={`garant-${n}`}>
                        Élément garant {ids.indexOf(n) + 1}
                    </span>
                    <Button variant="link" 
                    className="text-danger py-0 text-decoration-none"
                    onClick={(e)=>{that.delete_garant_input(n)}}
                    >Supprimer</Button>
                </Card.Text>
                
                <Form.Group as={Row} controlId="formPlaintextPassword">
                    <Form.Label column sm="4">
                    Intitulé*:
                    </Form.Label>
                    <Col sm="8">
                    <Form.Control 
                    type="text" 
                    placeholder="Intitulé" 
                    onChange={(e)=>{
                        let guarantees = that.state.guarantees;
                        let ind = that.state.ids_input_garants.indexOf(n);
                        if (guarantees.length > ind){
                            guarantees[ind]["label"] = e.target.value;
                        }
                        else{
                            guarantees.push({label: e.target.value, amount: 0, picture: ""})
                        }
                        that.setState({guarantees: guarantees.slice(0)});
                        that.check_garants();
                    }}
                    />
                    </Col>
                </Form.Group>

                <Form.Group as={Row} controlId="formPlaintextPassword">
                    <Form.Label column sm="4">
                    Montant estimé*:
                    </Form.Label>
                    <Col sm="8">
                    <Form.Control type="number" 
                    placeholder="Montant"
                    onChange={(e)=>{
                        let guarantees = that.state.guarantees;
                        let ind = that.state.ids_input_garants.indexOf(n);
                        if (guarantees.length > ind){
                            guarantees[ind]["amount"] = e.target.value;
                        }
                        else{
                            guarantees.push({label: "", amount: e.target.value, picture: ""})
                        }
                        that.setState({guarantees: guarantees.slice(0)});
                        that.check_garants();
                    }}
                    />
                    </Col>
                </Form.Group>

                <Form.File
                    label="Aperçu"
                    custom
                    onChange={(e) => {this.handleFileSelect(e,n)}}
                />
                <div><output id={`output-${n}`} className="mt-3"></output></div>
            </Card>
        );
        that.setState({
            input_garants: inputs.slice(0),
            ids_input_garants: ids.slice(0),
            total_created_garants: n + 1
        });
    }

    delete_garant_input(i){
        let that = this;
        let n = that.state.ids_input_garants.indexOf(i);
        let inputs = that.state.input_garants;
        let ids = that.state.ids_input_garants;
        let guarantees = that.state.guarantees;
        inputs.splice(n, 1);
        ids.splice(n, 1);
        guarantees.splice(n, 1);
        for(var j=0; j<ids.length; j++){
            document.getElementById(`garant-${ids[j]}`).innerHTML = "Élément garant " + (j + 1);
        }
        that.setState({
            input_garants: inputs.slice(0),
            ids_input_garants: ids.slice(0)
        })
    }

    handleFileSelect(e, i) {
        let that = this;
        let files = e.target.files;
        let file = files[0];
        if (files!=null && file.type.match('image.*')) {
          let reader = new FileReader();
    
          reader.readAsDataURL(file);
          reader.onload = function () {
            let output = document.getElementById(`output-${i}`);
            output.innerHTML = ['<img class="thumbnail" src="', reader.result,
            '" title="', escape(file.name), '" width=64 height=64/>'].join('');

            let guarantees = that.state.guarantees;
            let ind = that.state.ids_input_garants.indexOf(i);
            if (guarantees.length > ind){
                guarantees[ind]["picture"] = reader.result;
            }
            else{
                guarantees.push({label: "", amount: 0, picture: reader.result})
            }
            that.setState({guarantees: guarantees.slice(0)})
            that.check_garants();
        };
          // Do your things
        } else {
          // do your things
        }
      }

    check_deadlines(){
        let that = this;
        let flag = true;
        let result = that.state.deadlines.find((deadline)=>{return (deadline.payable_amount === 0 || deadline.deadline_date === "")});
        if(result){
            that.setState({deadlines_filled: false})
        }
        else{
            for(var i=0; i<that.state.deadlines.length - 1; i++){
                if(that.state.deadlines[i].deadline_date.diff(that.state.deadlines[i+1].deadline_date, 'days') >= 0){
                    flag = false;
                    break;
                }
            }
            if(that.state.deadlines.length){
                if(that.state.deadlines[that.state.deadlines.length-1].deadline_date.diff(that.state.due_date, 'days') > 0){
                    flag = false;
                }
            }
            that.setState({valid_deadlines_date: flag, deadlines_filled: true})
        }
        let sum = (that.state.deadlines.reduce((a, b) => a + ((b["payable_amount"]- 0) || 0), 0));
        let flag2 = (0 === (sum - that.state.amount_indebted));
        that.setState({valid_deadlines_amount: flag2});
    }

    check_garants(){
        let that = this;
        let sum = that.state.guarantees.reduce((a, b) => a + ((b["amount"]- 0) || 0), 0);
        let flag = (0 <= (sum - that.state.amount_indebted ));
        that.setState({valid_guarantees_amount: flag});
        let result = that.state.guarantees.find((garant)=>{return (garant.amount === 0 || garant.picture === "" || garant.label === "")});
        if(result){
            that.setState({guarantees_filled: false})
        }
        else{
            that.setState({guarantees_filled: true})
        }
    }

    can_submit(){
        let that = this;
        let flag = that.state.valid_client && that.state.valid_motif && that.state.valid_montant && that.state.valid_deadline_number && that.state.valid_due_date && that.state.valid_penalty &&  that.state.valid_deadlines_amount && that.state.valid_deadlines_date && that.state.valid_guarantees_amount && that.state.deadlines_filled && that.state.guarantees_filled;
        return flag;
    }

    submit(){
        let that = this;
        this.setState({submitting: true, submitted: true});
        if(!this.state.timeliner){
            this.check_deadlines();
            this.check_garants();
            this.submit_timeliner();
        }
        else if(this.state.client_agreement){
            const options = {
                headers: {
                    'Content-Type': 'application/json',
                    'authorization': `Token ${that.state.token}`
                }
            };
            let data = {
                client_agreement: that.state.client_agreement
            }
            axios.patch(`https://api-ksm-dateliner.herokuapp.com/api/time_liner/${that.state.timeliner}/`, data, options)
            .then(function (response) {
                that.setState({submitting: false, ok: true});
            })
            .catch(function (error){
                that.setState({submitting: false});
                console.log(error);
            });
        }
        else{
            this.setState({submitting: false});
        }
    }

    submit_timeliner(){
        let that = this;
        const options = {
            headers: {
                'Content-Type': 'application/json',
                'authorization': `Token ${that.state.token}`
            }
        };
        let data = {
            motif: that.state.motif,
            amount_indebted: that.state.amount_indebted,
            due_date: that.state.due_date,
            date_liner_number: that.state.date_liner_number,
            penalty_rate: that.state.penalty_rate,
            partner_id: that.state.partner_id,
            currency_id: that.state.currency
        }
        axios.post(`https://api-ksm-dateliner.herokuapp.com/api/time_liner/`, data, options)
        .then(function (response) {
            that.submit_dateliner(0, response.data.id);
            that.setState({timeliner: response.data.id});
        })
        .catch(function (error){
            //console.log(error.message, error.request, error.config, error.response);
            that.setState({submitting: false});
        });
    }

    submit_dateliner(i, timeliner){
        let that = this;
        const options = {
            headers: {
                'Content-Type': 'application/json',
                'authorization': `Token ${that.state.token}`
            }
        };
        let data = {
            payable_amount: that.state.deadlines[i].payable_amount,
            deadline_date: that.state.deadlines[i].deadline_date,
            time_liner_id: timeliner
        }
        axios.post(`https://api-ksm-dateliner.herokuapp.com/api/date_liner/`, data, options)
        .then(function (response) {
            that.submit_reminders(response.data.id);
            if(i+1 < that.state.deadlines.length){
                that.submit_dateliner(i+1, timeliner);
            }
            else{
                that.submit_guarantee(0, timeliner);
            }
        })
        .catch(function (error){
            //console.log(error.message, error.request, error.config, error.response);
            that.setState({submitting: false});
        });
    }

    submit_reminders(dateliner){
        let that = this;
        const options = {
            headers: {
                'Content-Type': 'application/json',
                'authorization': `Token ${that.state.token}`
            }
        };
        for(var i=0; i< that.state.reminders_list.length; i++){
            let data = {
                reminder_mean_id: that.state.reminders_list[i],
                date_liner_id: dateliner
            }
            axios.post(`https://api-ksm-dateliner.herokuapp.com/api/reminder/`, data, options)
            .then(function (response) {
            })
            .catch(function (error){
                //console.log(error.message, error.request, error.config, error.response);
                that.setState({submitting: false});
            });
        }
    }

    submit_guarantee(i, timeliner){
        let that = this;
        const options = {
            headers: {
                'Content-Type': 'application/json',
                'authorization': `Token ${that.state.token}`
            }
        };
        let data = {
            time_liner_id: timeliner,
            label: that.state.guarantees[i].label,
            amount: that.state.guarantees[i].amount,
            image: that.state.guarantees[i].picture
        }
        axios.post(`https://api-ksm-dateliner.herokuapp.com/api/guarantee_object/`, data, options)
        .then(function (response) {
            if(i+1 < that.state.guarantees.length){
                that.submit_guarantee(i+1, timeliner);
            }
            else{
                setTimeout(
                    ()=>{that.setState({submitting: false, contractReady: true})}, 1000
                )
                that.setState({submitting: false});
            }
        })
        .catch(function (error){
            //console.log(error.message, error.request, error.config, error.response);
            that.setState({submitting: false});
        });
    }

    render() {
        if(this.state.ok){
            return <Redirect push to={`/home:success`} />;
        }
        return (
            <>
                <Modal
                    show={this.state.modal}
                    onHide={(e)=>{this.setState({modal: false})}}
                    backdrop="static"
                    keyboard={false}
                >
                    <Modal.Header closeButton>
                    <Modal.Title>Confirmation</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                    Confirmer l'enregistrement du contrat.
                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant="secondary" onClick={(e)=>{this.setState({modal: false})}}>
                            Annuler
                        </Button>
                        <Button variant="primary" onClick={(e)=>{
                            this.submit();
                            this.setState({modal: false});
                        }}>Ok</Button>
                    </Modal.Footer>
                </Modal>
                <Card body bg="transparent" className="border-0 rounded-0">
                    <Card.Title className="text-center border-bottom pb-2">Accord entre Parties</Card.Title>
                    <Container className="mt-5">
                        {this.state.timeliner && this.state.contractReady?
                            <Card body className="p-0 m-0 rounded-0 shadow-sm">
                                <iframe src={`https://api-ksm-dateliner.herokuapp.com/api/sample_contract/${this.state.timeliner}`}
                                    id="frame"
                                    frameBorder="0" className="w-100"
                                    onLoad={(e)=>{
                                        let frame = document.getElementById('frame');
                                        let contentWindow = frame.contentWindow;
                                        contentWindow.postMessage('height','*');
                                        //frame.style.height = doc.body.scrollHeight + 12 + 'px';
                                    }}>
                                </iframe>
                        </Card>:
                            
                            <Row>
                                <Col className="px-0" sm>
                                    <Card body bg="transparent" className="border-0 rounded-0 pt-0">
                                        <Card.Title className="border-bottom pb-2">Informations Générales</Card.Title>

                                        <Form.Group as={Row} controlId="formPlaintextPassword">
                                            <Form.Label column sm="4">
                                            Client / Créancier*:
                                            </Form.Label>
                                            <Col sm="8">
                                            <Typeahead
                                                onChange={(selected) => {
                                                    // Handle selections...
                                                    if(!selected[0]){
                                                        this.setState({valid_client: false})
                                                    }
                                                    else{
                                                        this.setState({
                                                            partner_id: selected[0].id,
                                                            valid_client: true
                                                        });
                                                    }
                                                }}
                                                options={this.state.customers}
                                                placeholder="Nom du client ou du créancier"
                                            />
                                            {this.state.submitted && !this.state.valid_client ?
                                                <Form.Text className="text-danger mb-2">
                                                Veuillez sélectionner le client.
                                                </Form.Text>:
                                                <></>
                                            }
                                            </Col>
                                        </Form.Group>

                                        <Form.Group as={Row} controlId="formPlaintextPassword">
                                            <Form.Label column sm="4">
                                            Motif*:
                                            </Form.Label>
                                            <Col sm="8">
                                            <Form.Control type="text" 
                                            placeholder="Motif de la créance"
                                            onChange={(e) => {
                                                if(e.target.value){
                                                    this.setState({motif: e.target.value, valid_motif: true})
                                                }
                                                else{
                                                    this.setState({motif: e.target.value, valid_motif: false})
                                                }
                                            }}
                                            />
                                            {this.state.submitted && !this.state.valid_motif ?
                                                <Form.Text className="text-danger mb-2">
                                                Veuillez entrer le motif.
                                                </Form.Text>:
                                                <></>
                                            }
                                            </Col>
                                        </Form.Group>
                                        
                                        <Form.Group as={Row} controlId="formPlaintextPassword">
                                            <Form.Label column sm="4">
                                            Montant dette*:
                                            </Form.Label>
                                            <Col sm="5">
                                            <Form.Control 
                                            type="number" 
                                            onChange={(e) => {
                                                this.setState({
                                                    amount_indebted: e.target.value,
                                                    amount_letters: writtenNumber(e.target.value, {lang: 'fr'})
                                                });
                                                this.check_deadlines();
                                                this.check_garants();
                                                if (e.target.value <= 0){
                                                    this.setState({
                                                        valid_montant: false
                                                    });
                                                }
                                                else{
                                                    this.setState({
                                                        valid_montant: true
                                                    });
                                                }
                                            }}
                                            placeholder="Montant de la dette" />
                                            {this.state.submitted && !this.state.valid_montant ?
                                                <Form.Text className="text-danger mb-2">
                                                Veuillez entrer le montant.
                                                </Form.Text>:
                                                <></>
                                            }
                                            </Col>
                                            <Col sm="3">
                                            <Form.Control as="select" 
                                            onChange={(e) => {this.setState({currency: e.target.value})}}
                                            custom>
                                                {this.state.currencies.map((variant, idx) =>{
                                                    return (
                                                    <>
                                                        <option value={variant.id}>{variant.code}</option>
                                                    </>)
                                                })}
                                            </Form.Control>
                                            </Col>
                                        </Form.Group>

                                        <Form.Group as={Row} controlId="formPlaintextEmail">
                                            <Form.Label column sm="4">
                                            Montant en Lettres:
                                            </Form.Label>
                                            <Col sm="8">
                                            <Form.Control plaintext readOnly defaultValue="zero" value={this.state.amount_letters}/>
                                            </Col>
                                        </Form.Group>

                                        <Form.Group as={Row} controlId="formPlaintextPassword">
                                            <Form.Label column sm="4">
                                            Payable en*:
                                            </Form.Label>
                                            <Col sm="8">
                                            <Form.Control 
                                            type="number" 
                                            placeholder="Nombre d'échéances"
                                            onChange={(e) => {
                                                this.reset_echeance_inputs(e.target.value)
                                                if(e.target.value){
                                                    this.setState({
                                                        date_liner_number: e.target.value,
                                                        valid_deadline_number: true
                                                    });
                                                }
                                                else{
                                                    this.setState({
                                                        date_liner_number: e.target.value,
                                                        valid_deadline_number: false
                                                    });
                                                }
                                                }} />
                                            {this.state.submitted && !this.state.valid_deadline_number ?
                                                <Form.Text className="text-danger mb-2">
                                                Veuillez entrer le nombre d'échéances.
                                                </Form.Text>:
                                                <></>
                                            }
                                            </Col>
                                        </Form.Group>

                                        <Form.Group as={Row} controlId="formPlaintextPassword">
                                            <Form.Label column sm="4">
                                            Date Butoire*:
                                            </Form.Label>
                                            <Col sm="8">
                                            <DatePicker 
                                            minDate={this.state.startDate}
                                            onChange={(e) => {
                                                this.setState({due_date: e.date, valid_due_date: true})
                                            
                                            }}
                                            />
                                            {this.state.submitted && !this.state.valid_due_date ?
                                                <Form.Text className="text-danger mb-2">
                                                Veuillez entrer la date de l'échéance.
                                                </Form.Text>:
                                                <></>
                                            }
                                            </Col>
                                        </Form.Group>

                                        <Form.Group as={Row} controlId="formPlaintextPassword">
                                            <Form.Label column sm="4">
                                            Taux de peinalité*:
                                            </Form.Label>
                                            <Col sm="3">
                                            <Form.Control type="number" placeholder="(%)" 
                                                onChange={(e) => {
                                                    let value = (this.state.amount_indebted * e.target.value)/100.0;
                                                    this.setState({
                                                        penalty_rate: e.target.value,
                                                        penalty_amount: value,
                                                        valid_penalty: true
                                                    })}}
                                            />
                                            {this.state.submitted && !this.state.valid_penalty ?
                                                <Form.Text className="text-danger mb-2">
                                                Veuillez entrer le taux de peinalité.
                                                </Form.Text>:
                                                <></>
                                            }
                                            </Col>
                                            <Col sm="5">
                                            <Form.Control plaintext readOnly defaultValue="0" value={this.state.penalty_amount}/>
                                            </Col>
                                        </Form.Group>

                                        {this.state.input_echeances}
                                        <Form.Group as={Row} controlId="formPlaintextPassword">
                                            <Form.Label column sm="4">
                                            </Form.Label>
                                            <Col sm="8">
                                            {this.state.submitted && !this.state.valid_deadlines_amount && this.state.deadlines_filled ?
                                                <Form.Text className="text-danger mb-2">
                                                La somme des montants doit être égale au montant de la dette.
                                                </Form.Text>:
                                                <></>
                                            }
                                            {this.state.submitted && !this.state.valid_deadlines_date && this.state.deadlines_filled ?
                                                <Form.Text className="text-danger mb-2">
                                                Les dates doivent être successives et inférieures à la date finale.
                                                </Form.Text>:
                                                <></>
                                            }
                                            {this.state.submitted && !this.state.deadlines_filled ?
                                                <Form.Text className="text-danger mb-2">
                                                Veuillez remplir tous les champs.
                                                </Form.Text>:
                                                <></>
                                            }
                                            </Col>
                                        </Form.Group>
                                        <Card.Title className="border-bottom pb-2 mt-5">Moyens et Priorités des relances</Card.Title>
                                        
                                        <Form.Group as={Row} controlId="formPlaintextPassword">
                                            <Form.Label column sm="4">
                                            Relance 1*:
                                            </Form.Label>
                                            <Col sm="8">
                                            <Form.Control as="select" 
                                            onChange={(e) => {
                                                let means = this.state.reminders_list;
                                                means[0] = e.target.value;
                                                this.setState({reminders_list: means})}}
                                            custom>
                                                {this.state.reminder_means.map((variant, idx) =>{
                                                    return (
                                                    <>
                                                        <option value={variant.id}>{variant.label}</option>
                                                    </>)
                                                })}
                                            </Form.Control>
                                            </Col>
                                        </Form.Group>

                                        <Form.Group as={Row} controlId="formPlaintextPassword">
                                            <Form.Label column sm="4">
                                            Relance 2*:
                                            </Form.Label>
                                            <Col sm="8">
                                            <Form.Control as="select" 
                                            onChange={(e) => {
                                                let means = this.state.reminders_list;
                                                means[1] = e.target.value;
                                                this.setState({reminders_list: means})}}
                                            custom>
                                                {this.state.reminder_means.map((variant, idx) =>{
                                                    return (
                                                    <>
                                                        <option value={variant.id}>{variant.label}</option>
                                                    </>)
                                                })}
                                            </Form.Control>
                                            </Col>
                                        </Form.Group>

                                        <Form.Group as={Row} controlId="formPlaintextPassword">
                                            <Form.Label column sm="4">
                                            Relance 3*:
                                            </Form.Label>
                                            <Col sm="8">
                                            <Form.Control as="select" 
                                            onChange={(e) => {
                                                let means = this.state.reminders_list;
                                                means[2] = e.target.value;
                                                this.setState({reminders_list: means})}}
                                            custom>
                                                {this.state.reminder_means.map((variant, idx) =>{
                                                    return (
                                                    <>
                                                        <option value={variant.id}>{variant.label}</option>
                                                    </>)
                                                })}
                                            </Form.Control>
                                            </Col>
                                        </Form.Group>

                                        <Form.Group as={Row} controlId="formPlaintextPassword">
                                            <Form.Label column sm="4">
                                            Relance 4*:
                                            </Form.Label>
                                            <Col sm="8">
                                            <Form.Control as="select" 
                                            onChange={(e) => {
                                                let means = this.state.reminders_list;
                                                means[3] = e.target.value;
                                                this.setState({reminders_list: means})}}
                                            custom>
                                                {this.state.reminder_means.map((variant, idx) =>{
                                                    return (
                                                    <>
                                                        <option value={variant.id}>{variant.label}</option>
                                                    </>)
                                                })}
                                            </Form.Control>
                                            </Col>
                                        </Form.Group>
                                    
                                    </Card>
                                </Col>
                                <MediaQuery query='(min-width: 768px)'>
                                <Col className="border-left px-0" sm>
                                    <Card body bg="transparent" className="border-0 rounded-0 pt-0">
                                        <Card.Title className="border-bottom pb-2">Garants de la dette</Card.Title>
                                        {this.state.input_garants}
                                        {this.state.submitted && !this.state.valid_guarantees_amount && this.state.guarantees_filled && this.state.guarantees.length > 0 ?
                                            <Form.Text className="text-danger mb-2 mx-4">
                                            La somme des montants doit être supérieur ou égale au montant de la dette.
                                            </Form.Text>:
                                            <></>
                                        }
                                        {this.state.submitted && !this.state.guarantees_filled && this.state.guarantees.length > 0?
                                            <Form.Text className="text-danger mb-2 mx-4">
                                            Veuillez remplir tous les champs.
                                            </Form.Text>:
                                            <></>
                                        }
                                        {this.state.submitted && this.state.guarantees.length <= 0 ?
                                            <Form.Text className="text-danger mb-2 mx-4">
                                            Veuillez ajouter au moins un élément garant.
                                            </Form.Text>:
                                            <></>
                                        }
                                        <Button variant="link" className="text-decoration-none" onClick={this.add_garant_input}>Ajouter un élément garant</Button>
                                    </Card>
                                </Col>
                                </MediaQuery>
                                <MediaQuery query='(max-width: 768px)'>
                                    <Col className="px-0" sm>
                                        <Card body bg="transparent" className="border-0 rounded-0 pt-0">
                                            <Card.Title className="border-bottom pb-2">Garants de la dette</Card.Title>
                                            {this.state.input_garants}
                                            {this.state.submitted && !this.state.valid_guarantees_amount && this.state.guarantees_filled ?
                                                <Form.Text className="text-danger mb-2 mx-4">
                                                La somme des montants doit être égale au montant de la dette.
                                                </Form.Text>:
                                                <></>
                                            }
                                            {this.state.submitted && !this.state.guarantees_filled && this.state.guarantees.length > 0?
                                                <Form.Text className="text-danger mb-2 mx-4">
                                                Veuillez remplir tous les champs.
                                                </Form.Text>:
                                                <></>
                                            }
                                            {this.state.submitted && this.state.guarantees.length <= 0 ?
                                                <Form.Text className="text-danger mb-2 mx-4">
                                                Veuillez ajouter au moins un élément garant.
                                                </Form.Text>:
                                                <></>
                                            }
                                            <Button variant="link" className="text-decoration-none" onClick={this.add_garant_input}>Ajouter un élément garant</Button>
                                        </Card>
                                    </Col>
                                </MediaQuery>
                                

                            </Row>
                        }
                        
                        {this.state.timeliner && !this.props.match.params.id?
                        <Card body bg="transparent" style={{maxWidth: "20rem"}} className="border-0 rounded-0 mx-auto text-center mt-4">
                            <Form.Group controlId="formBasicCheckbox">
                                <Form.Check 
                                    type="checkbox" 
                                    label="Accord du client"
                                    onChange={(e)=>{
                                        this.setState({client_agreement: e.target.checked});
                                    }} />
                                    {this.state.submitted && this.state.printed && !this.state.client_agreement?
                                        <Form.Text className="text-danger mb-2">
                                        Veuillez cochez la case.
                                        </Form.Text>:
                                        <></>
                                    }
                            </Form.Group>
                        </Card>:<></>}
                        

                        <Card body bg="transparent" className="border-0 rounded-0 mx-auto text-center">
                            {!this.props.match.params.id?
                                <Link to="/">
                                    <Button variant="outline-danger" size="sm" className="rounded-0 px-4 mr-4">
                                        Annuler
                                    </Button>
                                </Link>:
                                <></>
                            }
                            {this.state.timeliner?
                                <Button variant="outline-dark" size="sm" 
                                    onClick={(e)=>{
                                        let frame = document.getElementById('frame');
                                        let contentWindow = frame.contentWindow;
                                        contentWindow.postMessage('print','*');
                                        this.setState({printed: true})
                                    }}
                                    className="rounded-0 px-4 mr-4">
                                    Imprimer
                                </Button>:
                                <></>
                            }
                            {!this.props.match.params.id?
                                <Button variant="primary" size="sm" className="rounded-0 px-4" onClick={(e)=>{
                                    if(this.can_submit()){
                                        this.setState({modal: true})
                                    }
                                }}>
                                    {(()=> {
                                        if (this.state.submitting) {
                                        return <Spinner animation="border" size="sm" className="mr-2"/>;
                                    }
                                    })()}
                                    Envoyer
                                </Button>:
                                <></>
                            }
                        </Card>

                    </Container>
                </Card>
            </>
        )
    }
}

export default Contract;