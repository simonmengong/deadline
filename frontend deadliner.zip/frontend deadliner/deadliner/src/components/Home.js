import React, { Component } from 'react';
import {Card, Button, Navbar, Nav, Container, Alert} from 'react-bootstrap'
import axios from 'axios';
import 'react-bootstrap-typeahead/css/Typeahead.css';
import moment from 'moment';
import MediaQuery from 'react-responsive';
import { BrowserRouter as Router, Route, Switch, Redirect, Link } from 'react-router-dom';
import Accueil from "./Accueil";
import Contract from "./Contract";
import Login from "./Login";
import Client from "./Client";
import Echeance from "./Echeance";
import {createBrowserHistory} from 'history';

class Home extends Component {
    constructor(props) {
        super(props);
        this.state = {
            username: "",
            history: createBrowserHistory()
        };
    }

    componentDidMount(props){
        let storage = window.localStorage;
        this.setState({
            username: storage.getItem('username')
        });
        document.title = "Yowyob Dateliner"
    }

    componentDidUpdate(props){
       let that = this;
        /*if(!this.state.updated){
            that.getContract();
            if(that.state.contract){
                that.setState({updated: true});
            }
        }*/
        if(that.state.username === ""){
            let storage = window.localStorage;
            that.setState({
                username: storage.getItem('username')
            });
        }
        
      }

    render() {
        return (
            <>
                <Navbar collapseOnSelect expand="lg" className="border-bottom shadow-sm mb-5">
                    <Navbar.Brand href="#home" className="font-weight-bold">Dateliner</Navbar.Brand>
                    <Navbar.Toggle aria-controls="responsive-navbar-nav"/>
                    <Navbar.Collapse className="justify-content-end" id="responsive-navbar-nav">
                        <Nav className="mx-auto">
                            <Nav.Link href="/" className="mr-5">Accueil</Nav.Link>
                            <Nav.Link href="/contract" className="mr-5">Contrat</Nav.Link>
                            <Nav.Link href="/customers" className="mr-5">Clients</Nav.Link>
                            <Nav.Link href="/deadlines">Échéances</Nav.Link>
                        </Nav>
                        <Navbar.Text>
                            {(()=> {
                                if (this.state.username) {
                                    return (
                                    <>
                                    Signed in as: 
                                    <a href="#" className="mr-3 ml-2">
                                    {this.state.username}
                                    </a>
                                    <a 
                                        href="#" 
                                        className="mr-3" 
                                        onClick={(e)=>{
                                            window.localStorage.removeItem("token");
                                            window.localStorage.removeItem("username");
                                            this.setState({username: ""})
                                    }}>Log out</a>
                                    </>)
                                }
                                else{
                                    return <><a href="login">Login</a></>
                                }
                            })()}
                        </Navbar.Text>
                    </Navbar.Collapse>
                </Navbar>
                <MediaQuery query='(min-width: 768px)'>
                    <Container className="mb-5">
                        <Card bg={"light2"} style={{minHeight: "80vh"}} className="border-0 rounded-0">
                        <Router>
                            <Switch>
                            <Route exact path='/home:success' component={Accueil}/>
                            <Route exact path='/' component={Accueil}/>
                            <Route exact path='/contract' component={Contract}/>
                            <Route exact path='/contract:id' component={Contract}/>
                            <Route exact path='/customers' component={Client}/>
                            <Route exact path='/login' component={Login}/>
                            <Route exact path='/login:then' component={Login}/>
                            <Route exact path='/deadlines' component={Echeance}/>
                            <Route exact path='/deadlines:id' component={Echeance}/>
                            </Switch>
                        </Router>
                        </Card>
                    </Container> 
                </MediaQuery>
                <MediaQuery query='(max-width: 768px)'>
                    <Container className="mb-5 px-0 mx-0" fluid>
                        <Card bg={"light2"} style={{minHeight: "80vh"}} className="border-0 rounded-0">
                        <Router>
                            <Switch>
                            <Route exact path='/home:success' component={Accueil}/>
                            <Route exact path='/' component={Accueil}/>
                            <Route exact path='/contract' component={Contract}/>
                            <Route exact path='/customers' component={Client}/>
                            <Route exact path='/login' component={Login}/>
                            <Route exact path='/login:then' component={Login}/>
                            <Route exact path='/deadlines' component={Echeance}/>
                            <Route exact path='/deadlines:id' component={Echeance}/>
                            </Switch>
                        </Router>
                        </Card>
                    </Container> 
                </MediaQuery>
                
            </>
        )
    }
}

export default Home;