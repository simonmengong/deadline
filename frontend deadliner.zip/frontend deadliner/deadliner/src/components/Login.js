import React, { Component } from 'react';
import {Card, Button, Navbar, Nav, Container, Row, Col, Form, Spinner} from 'react-bootstrap'
import axios from 'axios';
import { Typeahead } from 'react-bootstrap-typeahead';
import 'react-bootstrap-typeahead/css/Typeahead.css';
import { DateTimePicker } from "react-tempusdominus-bootstrap";
import moment from 'moment';
import MediaQuery from 'react-responsive';
import { BrowserRouter as Router, Route, Switch, Redirect, Link } from 'react-router-dom';


class Login extends Component {
    constructor(props) {
        super(props);
        this.state = {    
            isLoading : false,
            redirect : false,
            emptyField : true,
            invalidId: true,
            submitted: false,
            next: this.props.match.params.then !== undefined? this.props.match.params.then.replace(':', '') : ""
        };
        this.login = this.login.bind(this);
    }

    componentDidMount(props){
        /*let storage = window.localStorage;
        this.setState({
            token: storage.getItem('token')
        });
        window.scrollTo(0, 0)*/
    }

    componentDidUpdate(props){
       /* let that = this;
        if(!this.state.updated){
            that.getContract();
            if(that.state.contract){
                that.setState({updated: true});
            }
        }*/
      }
    
      login (e) {
        e.preventDefault();
        let name = document.getElementById('name').value;
        let password = document.getElementById('password').value;
        let that = this;
        this.setState({isLoading: true});
        if (name !== '' && password !== ''){
            axios.post('https://api-ksm-dateliner.herokuapp.com/api/login/', {
                name: name,
                password: password
            })
            .then(function (response) {
                if(response.data['msg'] === 'Identifiants invalides'){
                    that.setState({
                        isLoading: false,
                        submitted: true,
                        invalidId: true,
                        emptyField: false
                    });
                }
                else{
                    window.localStorage.setItem("token", response.data['token']);
                    window.localStorage.setItem("username", response.data['msg']);
                    that.setState({
                        isLoading: false,
                        redirect: true,
                        emptyField : false,
                        invalidId: false,
                        submitted: false
                    });
                    window.location.pathname = `/${that.state.next}`;
                }
            })
            .catch(function (error) {
                console.log(error);
            });
        }
        else{
            that.setState({
                submitted: true,
                emptyField: true,
                invalidId: false,
                isLoading: false
            })
        }
    }

    render() {
        /*if (this.state.redirect) {
            return <Redirect push to={`/${this.state.next}`} />;
        }*/
        return (
            <>
            <Card body bg="transparent" className="border-0 rounded-0 w-100">
                <Card.Title className="text-center border-bottom pb-2">Connexion</Card.Title>
                    <Card body bg="transparent" className="border-0 rounded-0 mx-auto" style={{maxWidth: "36rem"}}>
                        <Form.Group controlId="formBasicEmail">
                            <Form.Label>Username*:</Form.Label>
                            <Form.Control type="text" id="name" placeholder="Enter username" />
                        </Form.Group>

                        <Form.Group controlId="formBasicPassword">
                            <Form.Label>Password*:</Form.Label>
                            <Form.Control type="password" id="password" placeholder="Password" />
                        </Form.Group>
                        {this.state.submitted && this.state.invalidId ?
                            <Form.Text className="text-danger mb-2">
                            Identifiants Invalides.
                            </Form.Text>:
                            <></>
                        }
                        {this.state.submitted && this.state.emptyField ?
                            <Form.Text className="text-danger mb-2">
                            Veuillez renseigner tous les champs.
                            </Form.Text>:
                            <></>
                        }
                        <Button 
                            variant="primary" 
                            type="submit" 
                            size="sm" 
                            onClick={this.login}
                            className="rounded-0 px-3 mx-auto">
                            {(()=> {
                                if (this.state.isLoading) {
                                return <Spinner animation="border" size="sm" className="mr-2"/>;
                            }
                            })()}
                            Login
                        </Button>
                    </Card>
            </Card>
            </>
        )
    }
}

export default Login;