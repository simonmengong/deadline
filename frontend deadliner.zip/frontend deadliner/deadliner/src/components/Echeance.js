import React, { Component } from 'react';
import {Link } from 'react-router-dom';
import {Card, Button, Modal, DropdownButton, Dropdown, CardDeck, Accordion} from 'react-bootstrap'
import axios from 'axios';
import 'react-bootstrap-typeahead/css/Typeahead.css';
import moment from 'moment';
import MediaQuery from 'react-responsive';


class Echeance extends Component {
    constructor(props) {
        super(props);
        this.state = {
            token: null,
            dateLiners: [],
            guarantees: [],
            contractID: props.match.params.id? props.match.params.id.replace(':',''): "",
            contract: null,
            updated: false,
            now: moment(),
            bill: null,
            modalBill: false,
            modalRelance: false,
            mean: "SMS",
            hideOrshow: "Afficher"
        };

        this.getDateLiners = this.getDateLiners.bind(this);
        this.getContract = this.getContract.bind(this);
        this.payBill = this.payBill.bind(this);
        this.setContract = this.setContract.bind(this);
        this.makeRelance = this.makeRelance.bind(this);
        this.getGuarantees = this.getGuarantees.bind(this);
    }

    componentDidMount(props){
        let storage = window.localStorage;
        this.setState({
            token: storage.getItem('token')
        });
        window.scrollTo(0, 0)
    }

    getDateLiners(){
        let that = this;
        axios.get(`https://api-ksm-dateliner.herokuapp.com/api/date_liner_list_by_time_liner/${this.state.contractID}`, {
            headers: {
                'authorization': `Token ${this.state.token}`}
        })
        .then(function (response) {
            that.setState({dateLiners: response.data});
        })
        .catch(function (error){
            console.log(error);
        });
    }

    getGuarantees(){
        let that = this;
        axios.get(`https://api-ksm-dateliner.herokuapp.com/api/guarantee_object_list_by_time_liner/${this.state.contractID}`, {
            headers: {
                'authorization': `Token ${this.state.token}`}
        })
        .then(function (response) {
            that.setState({guarantees: response.data});
        })
        .catch(function (error){
            console.log(error);
        });
    }

    getContract(){
        let that = this;
        axios.get(`https://api-ksm-dateliner.herokuapp.com/api/time_liner/${this.state.contractID}/`, {
            headers: {
                'authorization': `Token ${this.state.token}`}
        })
        .then(function (response) {
            that.setState({contract: response.data});
            that.getDateLiners();
            that.getGuarantees();
        })
        .catch(function (error){
            console.log(error);
        });
    }

    setContract(){
        let that = this;
        const options = {
            headers: {
                'Content-Type': 'application/json',
                'authorization': `Token ${that.state.token}`
            }
        };
        let data = {
            status: 'SOLD'
        };
        axios.patch(`https://api-ksm-dateliner.herokuapp.com/api/time_liner/${that.state.contractID}/`, data, options)
        .then(function (response) {})
        .catch(function (error){
            console.log(error);
        });
    }

    makeRelance(){
        let that = this;
        axios.post(`https://api-ksm-dateliner.herokuapp.com/api/remind/${that.state.contractID}/${that.state.mean}`, null)
        .then(function (response) {})
        .catch(function (error){
            console.log(error);
        });
    }

    payBill(){
        let i = this.state.bill;
        let dateliner = this.state.dateLiners[i]
        let that = this;
        const options = {
            headers: {
                'Content-Type': 'application/json',
                'authorization': `Token ${that.state.token}`
            }
        };
        let data = {
            status: 'SOLD',
            accumulated_payment: dateliner.amount_due,
            amount_due: 0
        }
        axios.patch(`https://api-ksm-dateliner.herokuapp.com/api/date_liner/${dateliner.id}/`, data, options)
        .then(function (response) {
            that.setState({bill: null});
            that.getDateLiners();
            let flag = true;
            for(var i=0; i< that.state.dateLiners.length; i++){
                if(that.state.dateLiners[i].status !== "SOLD"){
                  flag = false;
                  break; 
                }
            };
            if(flag){
                that.setContract();
            }
        })
        .catch(function (error){
            console.log(error);
        });
    }

    componentDidUpdate(props){
        let that = this;
        if(!this.state.updated){
            that.getContract();
            if(that.state.contract){
                that.setState({updated: true});
            }
        }
      }

    render() {
        
        if(this.props.match.params.id){
            return (
                <>
                    <Modal
                        show={this.state.modalBill}
                        onHide={(e)=>{this.setState({modalBill: false, bill: null})}}
                        backdrop="static"
                        keyboard={false}
                    >
                        <Modal.Header closeButton>
                        <Modal.Title>Confirmation</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                        Confirmer le payement de la facture.
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="secondary" onClick={(e)=>{this.setState({modalBill: false, bill: null})}}>
                                Annuler
                            </Button>
                            <Button variant="primary" onClick={(e)=>{
                                this.payBill();
                                this.setState({modalBill: false});
                            }}>Ok</Button>
                        </Modal.Footer>
                    </Modal>
                    <Modal
                        show={this.state.modalRelance}
                        onHide={(e)=>{this.setState({modalRelance: false})}}
                        backdrop="static"
                        keyboard={false}
                    >
                        <Modal.Header closeButton>
                        <Modal.Title>Confirmation</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                        Confirmer la relance du client par {this.state.mean}.
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="secondary" onClick={(e)=>{this.setState({modalRelance: false})}}>
                                Annuler
                            </Button>
                            <Button variant="primary" onClick={(e)=>{
                                this.makeRelance();
                                this.setState({modalRelance: false});
                            }}>Ok</Button>
                        </Modal.Footer>
                    </Modal>
                    <Card className="border-0 bg-transparent">
                        <Card.Body>
                            {this.state.contract?
                                <Card.Title className="border-bottom text-center mb-5 pb-3">Écheances du contrat N° {this.state.contract.label}</Card.Title>
                                :
                                <></>
                            }
                            {this.state.guarantees.length?
                                <Accordion>
                                <Card className="border-0  bg-transparent">
                                    <Card.Header className="border-0 bg-transparent">
                                        <Accordion.Toggle 
                                            as={Button} 
                                            variant="dark" 
                                            size="sm" 
                                            eventKey="0"
                                            onClick={(e)=>{
                                                this.setState({hideOrshow: this.state.hideOrshow==='Afficher'?'Masquer':'Afficher'})
                                            }}
                                            className="text-decoration-none rounded-0">
                                            {this.state.hideOrshow} les éléments garants
                                        </Accordion.Toggle>
                                    </Card.Header>
                                    <Accordion.Collapse eventKey="0">
                                        <>
                                        <Card.Body className="d-flex flex-wrap">
                                            {this.state.guarantees.map((variant, idx) => {
                                                console.log(variant);
                                                return (
                                                <>
                                                    <Card style={{width: "16rem", minWidth:"16rem"}} className="bg-transparent rounded-0 mr-3 mb-3">
                                                        <Card.Body>
                                                            <Card.Title className="mb-3">Garant N° {idx+1}</Card.Title>
                                                            <Card.Text className="my-1">
                                                                <b>Intitulé:</b> {variant.label}
                                                            </Card.Text>
                                                            <Card.Text className="my-1">
                                                                <b>Montant estimé:</b> {variant.amount + " " + this.state.contract.currency.code}
                                                            </Card.Text>
                                                            <Card.Text className="my-1">
                                                                <b>Aperçu:</b>
                                                            </Card.Text>
                                                            <Card.Text>
                                                                <img class="thumbnail" src={variant.image} width={64} height={64}/>
                                                            </Card.Text>
                                                        </Card.Body>
                                                    </Card>
                                                </>
                                                )})
                                            }
                                        </Card.Body>
                                        <hr/>
                                        </>
                                    </Accordion.Collapse>
                                </Card>
                            </Accordion>:<></>
                            }
                            
                            {
                                this.state.dateLiners.map((variant, idx) => {
                                        return (
                                        <>
                                            <Card body 
                                                className="border-0 bg-transparent pt-0"
                                                >
                                                <Card.Title className="mt-0 pb-2 d-flex justify-content-between">
                                                    <span className="font-weight-bold">
                                                        Echéance {idx + 1}
                                                    </span>
                                                    {variant.status=="SOLD"||variant.penalty_applied?<></>:
                                                        <div className="d-flex">
                                                            <Button variant="dark" size="sm"
                                                                    className="rounded-0 mr-3"  
                                                                    onClick={(e) => {this.setState({bill: idx, modalBill: true})}}>
                                                                Régler
                                                            </Button>
                                                            <DropdownButton 
                                                                id="dropdown-item-button"
                                                                title="Relancer"
                                                                size="sm"
                                                                variant="dark"
                                                                className="rounded-0"
                                                                >
                                                                <Dropdown.Item as="button"onClick={()=>{this.setState({modalRelance: true, mean: "SMS"})}}>SMS</Dropdown.Item>
                                                                <Dropdown.Item as="button"onClick={()=>{this.setState({modalRelance: true, mean: "Email"})}}>Email</Dropdown.Item>
                                                                <Dropdown.Item as="button"onClick={()=>{this.setState({modalRelance: true, mean: "Téléphone"})}}>Téléphone</Dropdown.Item>
                                                                <Dropdown.Item as="button" onClick={()=>{this.setState({modalRelance: true, mean: "Whatsapp"})}}>Whatsapp</Dropdown.Item>
                                                            </DropdownButton>
                                                        </div>
                                                    }
                                                    
                                                </Card.Title>
                                                
                                                <div className="d-flex w-100 justify-content-between">
                                                    <div>
                                                        <Card.Text className="my-1">
                                                        <b>Date:</b> {moment(variant.deadline_date).format("DD/MM/YYYY")}
                                                        </Card.Text>
                                                        <Card.Text className="my-1">
                                                        <b>Montant à payer:</b> {variant.payable_amount + " "+ this.state.contract.currency.code}
                                                        </Card.Text>
                                                        <Card.Text className="my-1">
                                                        <b>Échec:</b> {variant.penalty_applied? "Oui": "Non"}
                                                        </Card.Text>
                                                        <Card.Text className="my-1">
                                                        <b>Pénalité:</b> {variant.penalty_applied? variant.penalty_amount: 0 + " "+ this.state.contract.currency.code}
                                                        </Card.Text>
                                                        <Card.Text className="my-1">
                                                        <b>Règlement Cumulé:</b> {variant.accumulated_payment + " "+ this.state.contract.currency.code}
                                                        </Card.Text>
                                                        <Card.Text className="my-1">
                                                        <b>Reste à payer:</b> {variant.amount_due + " "+ this.state.contract.currency.code}
                                                        </Card.Text>
                                                        <Card.Text className="my-1">
                                                        <b>Statut:</b> <i className={variant.status=="SOLD"? "text-success": ""}>{variant.status}</i>
                                                        </Card.Text>
                                                    </div>
                                                </div>
                                            </Card>
                                            <hr className="my-1" style={{borderStyle: "dashed"}}/>
                                        </>
                                        )
                                    })
                            }
                        </Card.Body>
                    </Card>
                </>
            )
        }
        else{
            return(
                <>
                    <Card body className="border-0 bg-transparent text-center">
                        <Card.Title className="border-bottom mb-5 pb-3">Écheances</Card.Title>

                        <Link to="/customers">
                            <Button variant="dark" size="sm" className="rounded-0">
                                Sélectionner un contrat
                            </Button>
                        </Link>
                        <Card.Text className="pt-5">
                            Vous trouverez ici les détails de chaque échéance du contrat sélectionné.
                        </Card.Text>
                    </Card>
                </>
            )
        }
    }
}

export default Echeance;