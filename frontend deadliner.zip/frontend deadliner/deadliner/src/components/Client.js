import React, { Component } from 'react';
import {Card, Button, Navbar, Nav, Container, Row, Col, Form, Spinner} from 'react-bootstrap'
import axios from 'axios';
import { Typeahead } from 'react-bootstrap-typeahead';
import 'react-bootstrap-typeahead/css/Typeahead.css';
import { DateTimePicker } from "react-tempusdominus-bootstrap";
import moment from 'moment';
import MediaQuery from 'react-responsive';
import { BrowserRouter as Router, Route, Switch, Redirect, Link } from 'react-router-dom';



class Client extends Component {
    constructor(props) {
        super(props);
        this.state = {
            token: "",
            customers: [],
            filter: "",
            timeliners: [],
            results: [],
            loading: false,
        };

        this.apply_filter = this.apply_filter.bind(this);
        this.get_timeliners = this.get_timeliners.bind(this);
    }

    componentDidMount(props){
        let that = this;
        let storage = window.localStorage;
        this.setState({
            token: storage.getItem('token')
        });
        window.scrollTo(0, 0)
        axios.get(`https://anselme.pythonanywhere.com/partner-api/partners/`, {
            headers: {
                'authorization': `Basic ${btoa("simon" + ":" + "simonsuperuser")}`}
        })
        .then(function (response) {
            let customers = response.data['results'].map((customer, id) =>{
                return({label: customer.name, id: customer.id})
            })
            that.setState({customers: customers});
        })
        .catch(function (error){
            console.log(error);
        });
    }

    componentDidUpdate(props){
       /* let that = this;
        if(!this.state.updated){
            that.getContract();
            if(that.state.contract){
                that.setState({updated: true});
            }
        }*/
      }

    get_timeliners(id){
        let that = this;
        this.setState({loading: true});
        axios.get(`https://api-ksm-dateliner.herokuapp.com/api/time_liner_by_user/${id}`, {
            headers: {
                'authorization': `Token ${this.state.token}`}
        })
        .then(function (response) {
            that.setState({
                timeliners: response.data                 
            });
            that.apply_filter(that.state.filter);
        })
        .catch(function (error){
            console.log(error, error.message, error.config, error.request);
        });
    }

    apply_filter(filter){
        let that = this;
        if(filter){
            let results = that.state.timeliners.filter((timeliner)=>{return timeliner.status === filter});
            that.setState({results: results.slice(0)})
        }
        else{
            that.setState({results: that.state.timeliners.slice(0)})
        }
        this.setState({loading: false});
    }
    
      

    render() {
        return (
            <>
            <Card body bg="transparent" className="border-0 rounded-0 w-100 mx-auto">
                <Card.Title className="text-center border-bottom pb-2">Payement / Règlement des échéances</Card.Title>
                    <Card body bg="transparent" className="border-0 rounded-0 mx-auto" style={{maxWidth: "40rem"}}>
                    <Form.Group as={Row} controlId="formPlaintextPassword">
                        <Form.Label column sm="4">
                        Client / Créancier:
                        </Form.Label>
                        <Col sm="8">
                        <Typeahead
                            onChange={(selected) => {
                                // Handle selections...
                                if(!selected[0]){
                                    this.setState({timeliners: [], results: []})
                                }
                                else{
                                    this.get_timeliners(selected[0].id)
                                }
                            }}
                            options={this.state.customers}
                            placeholder="Nom du client ou du créancier"
                        />
                        </Col>
                    </Form.Group>
                    <fieldset>
                        <Form.Group as={Row}>
                        <Form.Label as="legend" column sm={4}>
                        Charger les créances *:
                        </Form.Label>
                        <Col sm={8}>
                            <Form.Check
                            type="radio"
                            label="Toutes"
                            name="formHorizontalRadios"
                            id="formHorizontalRadios1"
                            defaultChecked
                            onChange={(e)=>{
                                if(e.target.checked){
                                    this.setState({filter: ""});
                                    this.apply_filter("");
                                }
                            }}
                            />
                            <Form.Check
                            type="radio"
                            label="En cours"
                            name="formHorizontalRadios"
                            id="formHorizontalRadios2"
                            onChange={(e)=>{
                                if(e.target.checked){
                                    this.setState({filter: "ONGOING"});
                                    this.apply_filter("ONGOING");
                                }
                            }}
                            />
                            <Form.Check
                            type="radio"
                            label="Soldées"
                            name="formHorizontalRadios"
                            id="formHorizontalRadios3"
                            onChange={(e)=>{
                                if(e.target.checked){
                                    this.setState({filter: "SOLD"});
                                    this.apply_filter("SOLD");
                                }
                            }}
                            />
                            <Form.Check
                            type="radio"
                            label="Avec Pénalité"
                            name="formHorizontalRadios"
                            id="formHorizontalRadios4"
                            onChange={(e)=>{
                                if(e.target.checked){
                                    this.setState({filter: "LITIGATION"});
                                    this.apply_filter("LITIGATION");
                                }
                            }}
                            />
                        </Col>
                        </Form.Group>
                    </fieldset>
                    </Card>
                    <Card body bg="transparent" className="border-0 rounded-0 mx-auto" style={{maxWidth: "40rem"}}>
                        <Card.Title className="border-bottom pb-2">
                            
                            {this.state.loading?
                                <>
                                <Spinner animation="border" size="sm" className="mr-2 mb-1"/>
                                Veuillez patienter...
                                </>:
                                <>Résultat(s): {this.state.results.length} échéancier(s) trouvé(s)</>
                            }
                        </Card.Title>
                        {this.state.results.map((variant, idx) => {
                            return (
                                <>
                                    <Card body 
                                        className="border-0 bg-transparent pt-0"
                                        >
                                        <Card.Text className="border-bottom pb-2 d-flex justify-content-between">
                                            <span className="font-weight-bold">
                                                Contrat N° {variant.label}
                                            </span>
                                            <Link to={`/deadlines:${variant.id}`}>
                                                <Button variant="dark" size="sm" className="rounded-0">
                                                    Détails
                                                </Button>
                                            </Link>
                                            <Link to={`/contract:${variant.id}`}>
                                                <Button variant="dark" size="sm" className="rounded-0">
                                                    Revoir
                                                </Button>
                                            </Link>
                                        </Card.Text>
                                        <Card.Text className="my-1">
                                        <b>Motif:</b> {variant.motif}
                                        </Card.Text>
                                        <Card.Text className="my-1">
                                        <b>Montant de la dette:</b> {`${variant.amount_indebted} ${variant.currency.code}`} 
                                        </Card.Text>
                                        <Card.Text className="my-1">
                                        <b>Montant soldé:</b> {`${variant.amount_cleared} ${variant.currency.code}`}
                                        </Card.Text>
                                        <Card.Text className="my-1">
                                        <b>Statut:</b> <i className={variant.status=="SOLD"? "text-success": ""}>{variant.status}</i>
                                        </Card.Text>                                        
                                    </Card>
                                    <hr className="my-1" style={{borderStyle: "dashed"}}/>
                                </>
                                )
                            })
                        }
                    </Card>
                </Card>
            </>
        )
    }
}

export default Client;