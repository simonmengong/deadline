const { createProxyMiddleware } = require("http-proxy-middleware");

module.exports = function(app) {
app.use(
  "/api",
  createProxyMiddleware({
    target: `https://api-ksm-dateliner.herokuapp.com/`,
    headers: {
      accept: "application/json",
      method: "GET",
    },
    changeOrigin: true,
  })
);
}