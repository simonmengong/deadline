import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router, Route, Switch, Redirect } from 'react-router-dom';
import axios from 'axios';
import Home from './components/Home';


class ProtectedRoute extends Component {
  constructor(props) {
    super(props);

    this.state = {
        authenticated: true
    };
  }

  componentDidMount(props){
    let storage = window.localStorage;
    let token = storage.getItem('token');
    if(token === null){
      this.setState({ authenticated: false });
    }
    /*else{
      axios.get(`https://api-ksm-dateliner.herokuapp.com/api/reminder_mean/`, {
          headers: {
              'authorization': `Token ${this.state.token}`}
      })
      .then(function (response) {
      })
      .catch(function (error){
        window.localStorage.removeItem("token");
        window.localStorage.removeItem("username");
        this.setState({ authenticated: false });
      });
    }*/
  }
  
  render() {
    const { component: Component, ...props } = this.props;

    return (
      <Route 
        {...props} 
        render={props => (
          this.state.authenticated ?
            <Component {...props} /> :
            <Redirect to={`/login:${this.props.location.pathname.replace(/^\/|\/$/g, '')}`} />
        )} 
      />
    )
  }
}

function App() {
  return (
    <Router>
        <Switch>
          <ProtectedRoute exact path='/contract' component={Home}/>
          <ProtectedRoute exact path='/contract:id' component={Home}/>
          <ProtectedRoute exact path='/home:success' component={Home}/>
          <ProtectedRoute exact path='/customers' component={Home}/>
          <ProtectedRoute exact path='/deadlines' component={Home}/>
          <ProtectedRoute exact path='/deadlines:id' component={Home}/>
          <Route exact path='' component={Home} />
          <Route exact path='/' component={Home}/>
          <Route exact path='/login:then' component={Home}/>
          <Route exact path='/login' component={Home}/>
        </Switch>
    </Router>
  );
}

export default App;
