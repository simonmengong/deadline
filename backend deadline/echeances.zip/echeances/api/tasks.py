from __future__ import absolute_import, unicode_literals
from celery import shared_task
import api.models
import datetime
import relances.utils


@shared_task
def task_number_one():
    """
    le rôle de cette tâche qui sera exécutée chaque jour à minuit
    c'est de vérifier les dates des échéances si une échéance est passée
    on la marque d'une pénalité, et on relance le client
    :return: none
    """
    now = datetime.datetime.now()
    q = api.models.DateLiner.objects.filter(deadline_date__lte=now, penalty_applied=False)
    for d in q:
        d.penalty_applied = True
        d.save()
        query = d.time_liner.dateliner_set.filter(deadline_date__gte=now).order_by('deadline_date')
        dl = query.first()
        if dl:
            dl.amount_due += d.amount_due + d.penalty_amount
            dl.save()
        else:
            dl = d
            dl.pk = None
            dl.penalty_applied = False
            dl.amount_due += d.penalty_amount
            dl.save()
        user = relances.utils.get_user_by_id(id_=dl.time_liner.partner_id)
        message = "Cher(e) client(e), votre échéance " \
                  "est arrivée à son terme. Pensez à vous acquitter de votre dette."
        relances.utils.send_email(to=user['email'], message=message)
        relances.utils.send_sms(to=user['telephone'], message=message)


@shared_task
def task_number_two():
    """
    le rôle de cette tâche qui sera exécutée chaque jour à minuit
    c'est de relancer les clients conformément au contrat qu'ils ont passé
    :return: none
    """
    now = datetime.datetime.now()
    for i in [7, 3, 1, 0]:
        threshold = datetime.timedelta(days=i)
        q = api.models.DateLiner.objects.filter(deadline_date__lte=now + threshold)
        for dl in q:
            reminder = dl.reminder_set.first()
            user = relances.utils.get_user_by_id(id_=dl.time_liner.partner_id)
            message = "Cher(e) client(e), votre échéance " \
                      "arrive à son terme dans {} jours. Pensez à vous acquitter de votre dette.".format(i)
            if reminder:
                if reminder.reminder_mean.label == 'SMS':
                    relances.utils.send_sms(to=user['telephone'], message=message)
                elif reminder.reminder_mean.label == 'Email':
                    relances.utils.send_email(to=user['email'], message=message)
                elif reminder.reminder_mean.label == 'Whatsapp':
                    relances.utils.send_whatsapp_msg(to=user['whatsapp'], message=message)
                elif reminder.reminder_mean.label == 'Téléphone':
                    relances.utils.send_voice_message(to=user['telephone'], message=message)
                reminder.delete()
