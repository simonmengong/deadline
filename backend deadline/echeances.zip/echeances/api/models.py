from django.db import models
from django.dispatch import receiver
from django.utils import timezone
import datetime
import uuid
from django.db.models.signals import post_save
from django.utils.text import slugify


def date_one_month_later():
    """
    fonction permettant de définir la date dans un mois,
    utile pour la date par défaut des échéances
    """
    now = timezone.now()
    return now + datetime.timedelta(days=30)


class Currency(models.Model):
    """
    Model permettant de gérer les différentes devises des monnaies
    """
    code = models.CharField(max_length=3, default='XAF')
    label = models.CharField(max_length=255, default='franc CFA BEAC')
    description = models.TextField(blank=True)

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, unique=True)
    slug = models.SlugField(max_length=150, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ('id', )

    def save(self, *args, **kwargs):
        self.slug = slugify(f"{self.created_at} {str(self.updated_at)}")
        super(Currency, self).save(*args, **kwargs)


class ReminderMean(models.Model):
    """
    Model permettant de gérer les différents moyens de relance
    """
    label = models.CharField(max_length=255, default='SMS')
    description = models.TextField(blank=True)

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, unique=True)
    slug = models.SlugField(max_length=150, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def save(self, *args, **kwargs):
        self.slug = slugify(f"{self.created_at} {str(self.updated_at)}")
        super(ReminderMean, self).save(*args, **kwargs)


class TimeLiner(models.Model):
    """
    Model permettant de gérer les différents contrats
    """
    class Status(models.TextChoices):
        ONGOING = 'ONGOING'
        SOLD = 'SOLD'
        LITIGATION = 'LITIGATION'

    label = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    motif = models.CharField(max_length=255, default="Achat à crédit")
    description = models.TextField(blank=True)
    amount_indebted = models.FloatField(default=0.0)
    amount_guarantee = models.FloatField(default=0.0)
    due_date = models.DateTimeField(default=date_one_month_later)
    date_liner_number = models.IntegerField(default=3)
    penalty_rate = models.FloatField(default=0.01)
    entry_date = models.DateTimeField(default=timezone.now)
    client_agreement = models.BooleanField(default=True)
    status = models.CharField(
        max_length=30,
        choices=Status.choices,
        default=Status.ONGOING,
    )
    update_date_liner = models.BooleanField(default=False)
    partner_id = models.CharField(max_length=255, default='')
    currency = models.ForeignKey(Currency, on_delete=models.PROTECT)

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, unique=True)
    slug = models.SlugField(max_length=150, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    @property
    def amount_cleared(self):
        q = DateLiner.objects.filter(time_liner=self)
        amount = 0
        for d in q:
            amount += d.accumulated_payment
        return amount

    def save(self, *args, **kwargs):
        self.slug = slugify(f"{self.created_at} {str(self.updated_at)}")
        super(TimeLiner, self).save(*args, **kwargs)


class GuaranteeObject(models.Model):
    """
    Model permettant de gérer les objets garants de la dette
    """
    label = models.CharField(max_length=255, default='')
    description = models.TextField(blank=True)
    amount = models.FloatField(default=0.0)
    image = models.TextField(blank=True)
    time_liner = models.ForeignKey(TimeLiner, on_delete=models.PROTECT)

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, unique=True)
    slug = models.SlugField(max_length=150, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def save(self, *args, **kwargs):
        self.slug = slugify(f"{self.created_at} {str(self.updated_at)}")
        super(GuaranteeObject, self).save(*args, **kwargs)


class DateLiner(models.Model):
    """
    Model permettant de gérer les différentes échéances du contrat
    """
    class Status(models.TextChoices):
        ONGOING = 'ONGOING'
        SOLD = 'SOLD'
    deadline_code = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    payable_amount = models.FloatField(default=0.0)
    deadline_date = models.DateTimeField(default=date_one_month_later)
    penalty_applied = models.BooleanField(default=False)
    penalty_amount = models.FloatField(default=0.0)
    accumulated_payment = models.FloatField(default=0.0)
    amount_due = models.FloatField(default=0.0)
    status = models.CharField(
        max_length=30,
        choices=Status.choices,
        default=Status.ONGOING,
    )
    notes = models.TextField(blank=True)
    entry_date = models.DateTimeField(default=timezone.now)
    time_liner = models.ForeignKey(TimeLiner, on_delete=models.PROTECT)

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, unique=True)
    slug = models.SlugField(max_length=150, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def save(self, *args, **kwargs):
        self.slug = slugify(f"{self.created_at} {str(self.updated_at)}")
        super(DateLiner, self).save(*args, **kwargs)


@receiver(post_save, sender=DateLiner)
def date_line_handle(sender, instance, created, **kwargs):
    if created:
        instance.penalty_amount = (instance.time_liner.penalty_rate * instance.time_liner.amount_indebted)/100.0
        instance.amount_due = instance.payable_amount
        instance.save()
    elif instance.penalty_applied and instance.status != "SOLD" and \
            (instance.amount_due != instance.payable_amount + instance.penalty_amount - instance.accumulated_payment):
        instance.amount_due = instance.payable_amount + instance.penalty_amount - instance.accumulated_payment
        instance.save()


class Reminder(models.Model):
    """
    Model permettant de gérer les différentes relances d'une échéance
    """
    reminder_mean = models.ForeignKey(ReminderMean, on_delete=models.PROTECT)
    date_liner = models.ForeignKey(DateLiner, on_delete=models.PROTECT)
    message = models.TextField(blank=True)

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, unique=True)
    slug = models.SlugField(max_length=150, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def save(self, *args, **kwargs):
        self.slug = slugify(f"{self.created_at} {str(self.updated_at)}")
        super(Reminder, self).save(*args, **kwargs)
