from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
from django.contrib.auth import authenticate, login
from rest_framework.authtoken.models import Token
from rest_framework import generics
from . import serializers, models
from django.http import JsonResponse
from rest_framework.permissions import IsAuthenticated
import io
from django.http import FileResponse
from django.template.loader import get_template
from xhtml2pdf import pisa
from num2words import num2words
import relances.utils
import datetime
from django.shortcuts import render
from django.http import HttpResponse
from cgi import escape


def get_or_none(class_model, **kwargs):
    """
    fonction permettant de retourner l'objet correspondand au modèle
    et aux autres paramètres
    :param class_model:  le modèle
    :param kwargs: id ou autres attributs
    :return: l'objet correspondant
    """
    try:
        return class_model.objects.get(**kwargs)
    except class_model.DoesNotExist:
        return None


class CurrencyList(generics.ListCreateAPIView):
    """
    GET: retourne la liste de tous les objets
    POST: créer un objet
    """
    permission_classes = (IsAuthenticated,)
    queryset = models.Currency.objects.all()
    serializer_class = serializers.CurrencySerializer


class CurrencyDetail(generics.RetrieveUpdateDestroyAPIView):
    """
    GET: retourne l'objet
    PATCH: met à jour les paramètres passés
    POST: met à jour (tous les attributs doivent être passés)
    DELETE: supprime l'objet
    """
    permission_classes = (IsAuthenticated,)
    queryset = models.Currency.objects.all()
    serializer_class = serializers.CurrencySerializer


class ReminderMeanList(generics.ListCreateAPIView):
    """
    GET: retourne la liste de tous les objets
    POST: créer un objet
    """
    permission_classes = (IsAuthenticated,)
    queryset = models.ReminderMean.objects.all()
    serializer_class = serializers.ReminderMeanSerializer


class ReminderMeanDetail(generics.RetrieveUpdateDestroyAPIView):
    """
    GET: retourne l'objet
    PATCH: met à jour les paramètres passés
    POST: met à jour (tous les attributs doivent être passés)
    DELETE: supprime l'objet
    """
    permission_classes = (IsAuthenticated,)
    queryset = models.ReminderMean.objects.all()
    serializer_class = serializers.ReminderMeanSerializer


class TimeLinerList(generics.ListCreateAPIView):
    """
    GET: retourne la liste de tous les objets
    POST: créer un objet
    """
    permission_classes = (IsAuthenticated,)
    queryset = models.TimeLiner.objects.all()
    serializer_class = serializers.TimeLinerSerializer


class TimeLinerDetail(generics.RetrieveUpdateDestroyAPIView):
    """
    GET: retourne l'objet
    PATCH: met à jour les paramètres passés
    POST: met à jour (tous les attributs doivent être passés)
    DELETE: supprime l'objet
    """
    permission_classes = (IsAuthenticated,)
    queryset = models.TimeLiner.objects.all()
    serializer_class = serializers.TimeLinerSerializer


class GuaranteeObjectList(generics.ListCreateAPIView):
    """
    GET: retourne la liste de tous les objets
    POST: créer un objet
    """
    permission_classes = (IsAuthenticated,)
    queryset = models.GuaranteeObject.objects.all()
    serializer_class = serializers.GuaranteeObjectSerializer


class GuaranteeObjectDetail(generics.RetrieveUpdateDestroyAPIView):
    """
    GET: retourne l'objet
    PATCH: met à jour les paramètres passés
    POST: met à jour (tous les attributs doivent être passés)
    DELETE: supprime l'objet
    """
    permission_classes = (IsAuthenticated,)
    queryset = models.GuaranteeObject.objects.all()
    serializer_class = serializers.GuaranteeObjectSerializer


class DateLinerList(generics.ListCreateAPIView):
    """
    GET: retourne la liste de tous les objets
    POST: créer un objet
    """
    permission_classes = (IsAuthenticated,)
    queryset = models.DateLiner.objects.all()
    serializer_class = serializers.DateLinerSerializer


class DateLinerDetail(generics.RetrieveUpdateDestroyAPIView):
    """
    GET: retourne l'objet
    PATCH: met à jour les paramètres passés
    POST: met à jour (tous les attributs doivent être passés)
    DELETE: supprime l'objet
    """
    permission_classes = (IsAuthenticated,)
    queryset = models.DateLiner.objects.all()
    serializer_class = serializers.DateLinerSerializer


class ReminderList(generics.ListCreateAPIView):
    """
    GET: retourne la liste de tous les objets
    POST: créer un objet
    """
    permission_classes = (IsAuthenticated,)
    queryset = models.Reminder.objects.all()
    serializer_class = serializers.ReminderSerializer


class ReminderDetail(generics.RetrieveUpdateDestroyAPIView):
    """
    GET: retourne l'objet
    PATCH: met à jour les paramètres passés
    POST: met à jour (tous les attributs doivent être passés)
    DELETE: supprime l'objet
    """
    permission_classes = (IsAuthenticated,)
    queryset = models.Reminder.objects.all()
    serializer_class = serializers.ReminderSerializer


#  View classes spécifiquement pour react


class ExpireSoonTimeLinerList(generics.ListAPIView):
    """
    GET: retourne la liste de tous les objets
    """
    permission_classes = (IsAuthenticated,)
    queryset = models.TimeLiner.objects.filter(status__in=["LITIGATION", "ONGOING"]).order_by('due_date')[:4]
    serializer_class = serializers.TimeLinerSerializer


class TimeLinerByUserList(generics.ListAPIView):
    """
    GET: retourne la liste de tous les objets
    """
    permission_classes = (IsAuthenticated,)
    serializer_class = serializers.TimeLinerSerializer

    def get_queryset(self):
        """
        This view should return a list of all the purchases
        for the currently authenticated user.
        """
        client = self.kwargs['client']
        return models.TimeLiner.objects.filter(partner_id=client)


class DateLinerListByTimeLiner(generics.ListAPIView):
    """
    GET: retourne la liste de tous les objets
    """
    permission_classes = (IsAuthenticated,)
    serializer_class = serializers.DateLinerSerializer

    def get_queryset(self):
        """
        This view should return a list of all the purchases
        for the currently authenticated user.
        """
        time_liner = get_or_none(models.TimeLiner, id=self.kwargs['dateLiner'])
        return models.DateLiner.objects.filter(time_liner=time_liner)


@csrf_exempt
def user_login(request):
    """
    log a user in via the api.
    :return: un json contenant le token et le username si les identifiants sont bons
    sinon renvoie un message d'erreur
    """
    data = JSONParser().parse(request)
    username = data.get('name')
    raw_password = data.get('password')
    user = authenticate(username=username, password=raw_password)
    resp = {
        'token': '',
        'msg': 'Identifiants invalides'
    }
    if user is not None:
        login(request, user)
        token, created = Token.objects.get_or_create(user=user)
        resp['token'] = token.key
        resp['msg'] = user.get_username().capitalize()
    return JsonResponse(resp)


def send_reminder(request, contract):
    now = datetime.datetime.now()
    contract = get_or_none(models.TimeLiner, id=contract)
    resp = {
        'msg': 'bad request'
    }
    if contract:
        user = relances.utils.get_user_by_id(id_=contract.partnerID)
        dl = contract.dateliner_set.filter(deadlineDate__gte=now).first()
        if dl:
            message = "Cher(e) client(e), votre échéance " \
                      "arrive à son terme le {}. Pensez à vous acquitter de votre dette.".format(dl.deadlineDate.strftime("%d-%m-%Y") )
            relances.utils.send_sms(to=user['telephone'], message=message)
            resp = {
                'msg': 'ok'
            }
    return JsonResponse(resp)


def print_pdf(request, pk):
    contract = get_or_none(models.TimeLiner, id=pk)
    resp = {
        'msg': 'bad request'
    }
    if contract:
        user = relances.utils.get_user_by_id(contract.partner_id)
        q = models.DateLiner.objects.filter(time_liner=contract).order_by('deadline_date')
        if contract.date_liner_number == 1:
            date_liner_number = "une"
        else:
            date_liner_number = num2words(contract.date_liner_number, lang='fr')
        dateliners = [{'deadlineDate': dl.deadline_date,
                       'payable_amount': dl.payable_amount,
                       'payable_amount_letter': num2words(dl.payable_amount, lang='fr')} for dl in q]
        template = get_template("contract.html")
        context = {"contract": contract,
                   'amount_letter': num2words(contract.amount_indebted, lang='fr'),
                   'dln_letter': date_liner_number,
                   'date_liners': dateliners,
                   'user': user
                   }
        html = template.render(context, request)
        result = io.BytesIO()
        pdf = pisa.pisaDocument(io.BytesIO(html.encode("UTF-8")), result)
        result.seek(0)
        return FileResponse(result, as_attachment=True, filename='contract.pdf')
    return JsonResponse(resp)


def contract_sample(request, pk):
    contract = get_or_none(models.TimeLiner, id=pk)
    resp = {
        'msg': 'bad request'
    }
    if contract:
        user = relances.utils.get_user_by_id(contract.partner_id)
        q = models.DateLiner.objects.filter(time_liner=contract).order_by('deadline_date')
        if contract.date_liner_number == 1:
            date_liner_number = "une"
        else:
            date_liner_number = num2words(contract.date_liner_number, lang='fr')
        dateliners = [{'deadlineDate': dl.deadline_date,
                       'payable_amount': dl.payable_amount,
                       'payable_amount_letter': num2words(dl.payable_amount, lang='fr')} for dl in q]
        template = get_template("contract.html")
        context = {"contract": contract,
                   'amount_letter': num2words(contract.amount_indebted, lang='fr'),
                   'dln_letter': date_liner_number,
                   'date_liners': dateliners,
                   'user': user
                   }
        return render(request, "contract.html", context)
    return HttpResponse('We had some errors')
