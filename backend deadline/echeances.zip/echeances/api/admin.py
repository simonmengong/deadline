from django.contrib import admin
from . import models


admin.site.register(
    models.Currency,
    list_display=[
            'id',
            'code',
            'label',
            'description'
        ],
)

admin.site.register(
    models.ReminderMean,
    list_display=[
            'id',
            'label',
            'description'
        ],
)

admin.site.register(
    models.TimeLiner,
    list_display=[
            'id',
            'label',
            'description',
            'amount_indebted',
            'amount_guarantee',
            'due_date',
            'date_liner_number',
            'penalty_rate',
            'entry_date',
            'client_agreement',
            'status',
            'update_date_liner',
            'partner_id',
            'currency'
        ],
)

admin.site.register(
    models.GuaranteeObject,
    list_display=[
           'id',
           'label',
           'description',
           'amount',
           'time_liner'
        ],
)

admin.site.register(
    models.DateLiner,
    list_display=[
            'id',
            'deadline_code',
            'payable_amount',
            'deadline_date',
            'penalty_applied',
            'penalty_amount',
            'accumulated_payment',
            'amount_due',
            'status',
            'notes',
            'entry_date',
            'time_liner'
        ],
)

admin.site.register(
    models.Reminder,
    list_display=[
            'id',
            'reminder_mean',
            'date_liner',
            'message'
        ],
)
