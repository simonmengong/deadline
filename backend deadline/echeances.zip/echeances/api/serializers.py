from rest_framework import serializers
from . import models


class CurrencySerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Currency
        fields = [
            'id',
            'code',
            'label',
            'description'
        ]


class ReminderMeanSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.ReminderMean
        fields = [
            'id',
            'label',
            'description'
        ]


class TimeLinerSerializer(serializers.ModelSerializer):
    currency_id = serializers.PrimaryKeyRelatedField(
        source='currency',
        queryset=models.Currency.objects.all()
    )
    currency = CurrencySerializer(read_only=True)
    amount_cleared = serializers.IntegerField(read_only=True)

    class Meta:
        model = models.TimeLiner
        fields = [
            'id',
            'label',
            'motif',
            'description',
            'amount_indebted',
            'amount_guarantee',
            'due_date',
            'date_liner_number',
            'penalty_rate',
            'entry_date',
            'client_agreement',
            'status',
            'update_date_liner',
            'partner_id',
            'currency_id',
            'currency',
            'amount_cleared',
        ]


class GuaranteeObjectSerializer(serializers.ModelSerializer):
    time_liner_id = serializers.PrimaryKeyRelatedField(
        source='time_liner',
        queryset=models.TimeLiner.objects.all()
    )
    time_liner = TimeLinerSerializer(read_only=True)

    class Meta:
        model = models.GuaranteeObject
        fields = [
            'id',
            'label',
            'description',
            'amount',
            'image',
            'time_liner_id',
            'time_liner',
        ]


class DateLinerSerializer(serializers.ModelSerializer):
    time_liner_id = serializers.PrimaryKeyRelatedField(
        source='time_liner',
        queryset=models.TimeLiner.objects.all()
    )
    time_liner = TimeLinerSerializer(read_only=True)

    class Meta:
        model = models.DateLiner
        fields = [
            'id',
            'deadline_code',
            'payable_amount',
            'deadline_date',
            'penalty_applied',
            'penalty_amount',
            'accumulated_payment',
            'amount_due',
            'status',
            'notes',
            'entry_date',
            'time_liner_id',
            'time_liner',
        ]


class ReminderSerializer(serializers.ModelSerializer):
    reminder_mean_id = serializers.PrimaryKeyRelatedField(
        source='reminder_mean',
        queryset=models.ReminderMean.objects.all()
    )
    reminder_mean = ReminderMeanSerializer(read_only=True)
    date_liner_id = serializers.PrimaryKeyRelatedField(
        source='date_liner',
        queryset=models.DateLiner.objects.all()
    )
    date_liner = DateLinerSerializer(read_only=True)

    class Meta:
        model = models.Reminder
        fields = [
            'id',
            'reminder_mean_id',
            'reminder_mean',
            'date_liner_id',
            'date_liner',
            'message'
        ]
