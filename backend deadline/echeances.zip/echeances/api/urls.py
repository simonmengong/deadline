from . import views
from django.urls import path

urlpatterns = [
    path('currency/', views.CurrencyList.as_view()),
    path('currency/<uuid:pk>/', views.CurrencyDetail.as_view(), name='api.Currency'),
    path('reminder_mean/', views.ReminderMeanList.as_view()),
    path('reminder_mean/<uuid:pk>/', views.ReminderMeanDetail.as_view(), name='api.ReminderMean'),
    path('time_liner/', views.TimeLinerList.as_view()),
    path('time_liner/<uuid:pk>/', views.TimeLinerDetail.as_view(), name='api.TimeLiner'),
    path('guarantee_object/', views.GuaranteeObjectList.as_view()),
    path('guarantee_object/<uuid:pk>/', views.GuaranteeObjectDetail.as_view(), name='api.GuaranteeObject'),
    path('date_liner/', views.DateLinerList.as_view()),
    path('date_liner/<uuid:pk>/', views.DateLinerDetail.as_view(), name='api.DateLiner'),
    path('reminder/', views.ReminderList.as_view()),
    path('reminder/<uuid:pk>/', views.ReminderDetail.as_view(), name='api.Reminder'),


    # React JS Specific

    path('date_liner_list_by_time_liner/<uuid:dateLiner>', views.DateLinerListByTimeLiner.as_view()),
    path('expire_soon_time_liner_list/', views.ExpireSoonTimeLinerList.as_view()),
    path('time_liner_by_user/<uuid:client>', views.TimeLinerByUserList.as_view()),
    path('login/', views.user_login),
    path('contract/<uuid:pk>', views.print_pdf, name='api.contract'),
    path('sample_contract/<uuid:pk>', views.contract_sample, name='api.sample_contract'),
    path('remind/<uuid:contract>', views.send_reminder, name='api.remind')
]
