from twilio.rest import Client
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import requests
from requests import Request, Session
import datetime
import base64


MAIL_URL = 'https://api-services.yowyob.com/yowyob-services/api/v1/mailer/send'
ACCOUNT_SID = "AC466e140856d56b6a24efc87c087f7310"
AUTH_TOKEN = "abd5529564458e1b61be901ca91f8a8d"
NUMBER = "+12027988783"
MESSAGE_ENDPOINT = "https://api.twilio.com/" \
                   "2010-04-01/Accounts/{TWILIO_SID}" \
                   "/Messages.json".format(TWILIO_SID=ACCOUNT_SID)
WHATSAPP_NUMBER = "whatsapp:+14155238886"
client = Client(ACCOUNT_SID, AUTH_TOKEN)


def send_sms(to, message):
    message = client.messages.create(
        body=message,
        from_=NUMBER,
        to=to
    )
    print(message.sid)


def send_whatsapp_msg(to, message):
    message = client.messages.create(
        from_=WHATSAPP_NUMBER,
        body=message,
        to='whatsapp:{}'.format(to)
    )

    print(message.sid)


def send_voice_message(to, message):
    call = client.calls.create(
        twiml=
        '''<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="woman" language="fr-FR">{}</Say>
</Response>'''.format(message),
        to=to,
        from_=NUMBER
    )
    print(call.sid)


def send_email(to, message):
    html = """\
        <html>
          <head></head>
          <body>
               <h2> RELANCE </h2>
                <p>{}</p>
          </body>
        </html>
        """.format(message)
    request = Request(
        'POST',
        MAIL_URL,
        files={
            'from': (None, 'simon.mengong@yandex.com'),
            'to[0]': (None, to),
            'subject': (None, 'Votre échéance sur KSM DATELINERS'),
            'message': (None, html),
        }
    ).prepare()
    s = Session()
    response = s.send(request)
    print(response.text)


def get_user_by_id(id_):
    resp1 = requests.get(url='https://anselme.pythonanywhere.com/partner-api/partners/{}/'.format(id_),
                         auth=("simon", "simonsuperuser"))
    result = resp1.json()
    resp2 = requests.get(url='https://anselme.pythonanywhere.com/partner-api/contacts/',
                         auth=("simon", "simonsuperuser"))
    contacts = resp2.json()['results']
    user = result
    for contact in contacts:
        if contact["partner"] == id_:
            user = {**contact, **result}
            user['whatsapp'] = user['whatsapp_id']
            break
    return user


if __name__ == '__main__':
    # send_sms(to="+237655620400", message='Hi There!')
    # send_whatsapp_msg(to="+237655620400", message='Hi there !')
    #send_voice_message(to="+237655620400", message='Bonjour, la date limite de votre première échéance est dans 3 jours.')
    # send_email(to='simon.mengong@yahoo.fr', message='Bonjour, la date limite de votre première échéance est dans 3 jours.')
    # send_email(to="spmengong9@gmail.com", message='Bonjour, la date limite de votre première échéance est dans 3 jours.')
    print(get_user_by_id("a2df309d-4aca-4132-b9cb-c8dc1efb3e6c"))

